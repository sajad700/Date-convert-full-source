﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtYear = new System.Windows.Forms.TextBox();
            this.lblChange = new System.Windows.Forms.Label();
            this.btncul = new System.Windows.Forms.Button();
            this.txtMonth = new System.Windows.Forms.TextBox();
            this.txtDay = new System.Windows.Forms.TextBox();
            this.rdbMilladi = new System.Windows.Forms.RadioButton();
            this.rdbShms = new System.Windows.Forms.RadioButton();
            this.lblAD = new System.Windows.Forms.Label();
            this.lblSH = new System.Windows.Forms.Label();
            this.lblAH = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(448, 109);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(44, 20);
            this.txtYear.TabIndex = 0;
            this.txtYear.TextChanged += new System.EventHandler(this.txtBox_TextChanged);
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChange.Location = new System.Drawing.Point(504, 49);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(49, 22);
            this.lblChange.TabIndex = 1;
            this.lblChange.Text = "date";
            this.lblChange.Click += new System.EventHandler(this.lblChange_Click);
            // 
            // btncul
            // 
            this.btncul.Location = new System.Drawing.Point(489, 157);
            this.btncul.Name = "btncul";
            this.btncul.Size = new System.Drawing.Size(75, 23);
            this.btncul.TabIndex = 2;
            this.btncul.Text = "تبدیل";
            this.btncul.UseVisualStyleBackColor = true;
            this.btncul.Click += new System.EventHandler(this.btncul_Click);
            // 
            // txtMonth
            // 
            this.txtMonth.Location = new System.Drawing.Point(523, 108);
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.Size = new System.Drawing.Size(30, 20);
            this.txtMonth.TabIndex = 3;
            // 
            // txtDay
            // 
            this.txtDay.Location = new System.Drawing.Point(579, 108);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(31, 20);
            this.txtDay.TabIndex = 4;
            // 
            // rdbMilladi
            // 
            this.rdbMilladi.AutoSize = true;
            this.rdbMilladi.Location = new System.Drawing.Point(311, 74);
            this.rdbMilladi.Name = "rdbMilladi";
            this.rdbMilladi.Size = new System.Drawing.Size(91, 17);
            this.rdbMilladi.TabIndex = 5;
            this.rdbMilladi.TabStop = true;
            this.rdbMilladi.Text = "به میلادی/ AD";
            this.rdbMilladi.UseVisualStyleBackColor = true;
            this.rdbMilladi.CheckedChanged += new System.EventHandler(this.rdbMilladi_CheckedChanged);
            // 
            // rdbShms
            // 
            this.rdbShms.AutoSize = true;
            this.rdbShms.Location = new System.Drawing.Point(309, 114);
            this.rdbShms.Name = "rdbShms";
            this.rdbShms.Size = new System.Drawing.Size(93, 17);
            this.rdbShms.TabIndex = 6;
            this.rdbShms.TabStop = true;
            this.rdbShms.Text = "به شمسی/ SH";
            this.rdbShms.UseVisualStyleBackColor = true;
            // 
            // lblAD
            // 
            this.lblAD.AutoSize = true;
            this.lblAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAD.Location = new System.Drawing.Point(106, 69);
            this.lblAD.Name = "lblAD";
            this.lblAD.Size = new System.Drawing.Size(123, 22);
            this.lblAD.TabIndex = 9;
            this.lblAD.Text = "Anno Domini";
            // 
            // lblSH
            // 
            this.lblSH.AutoSize = true;
            this.lblSH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSH.Location = new System.Drawing.Point(106, 109);
            this.lblSH.Name = "lblSH";
            this.lblSH.Size = new System.Drawing.Size(99, 22);
            this.lblSH.TabIndex = 10;
            this.lblSH.Text = "Solar Hijri";
            // 
            // lblAH
            // 
            this.lblAH.AutoSize = true;
            this.lblAH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAH.Location = new System.Drawing.Point(106, 155);
            this.lblAH.Name = "lblAH";
            this.lblAH.Size = new System.Drawing.Size(129, 22);
            this.lblAH.TabIndex = 11;
            this.lblAH.Text = "Anno hegirae";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(308, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "input date type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(456, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "year";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(521, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "manth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(583, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "day";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 344);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblAH);
            this.Controls.Add(this.lblSH);
            this.Controls.Add(this.lblAD);
            this.Controls.Add(this.rdbShms);
            this.Controls.Add(this.rdbMilladi);
            this.Controls.Add(this.txtDay);
            this.Controls.Add(this.txtMonth);
            this.Controls.Add(this.btncul);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.txtYear);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Button btncul;
        private System.Windows.Forms.TextBox txtMonth;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.RadioButton rdbMilladi;
        private System.Windows.Forms.RadioButton rdbShms;
        private System.Windows.Forms.Label lblAD;
        private System.Windows.Forms.Label lblSH;
        private System.Windows.Forms.Label lblAH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int day, year, manth, century;
        string[] date;
        int[] plusmday = new int[12] {31,29,31,30,31,30,31,31,30,31,30,31};
        int[] mday = new int[12] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31,30,31};
        int[] plusshday = new int[12] { 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 30 };
        int[] shday = new int[12] { 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 };
        int[] pluslunarday = new int[12] { 30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, 30 };
        int[] lunarday = new int[12] { 30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, 29 };
        int[] taghsem = new int[11] { 2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29 };



        private void txtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btncul_Click(object sender, EventArgs e)
        {
            year =Convert.ToInt16( txtYear.Text);
            manth = Convert.ToInt16(txtMonth.Text);
            day = Convert.ToInt16(txtDay.Text);
            century= year % 100;

            if (rdbMilladi.Checked)
            {
                lblAD.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                shms_excute(day, manth, year, century);
                date = lblSH.Text.Split('/');
                int j = 0;
                foreach ( string i in date)
                {
                    if (j == 0)
                        year = Convert.ToInt32(i);
                    else if (j == 1)
                        manth = Convert.ToInt32(i);
                    else
                        day = Convert.ToInt32(i);
                    j++;
                }
                century = year % 100;
                lunar_excute(day, manth, year, century);
            }
            else if (rdbShms.Checked)
            {
                lblSH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                milladi_excute(day, manth, year, century);
                date = lblSH.Text.Split('/');
                int j = 0;
                foreach (string i in date)
                {
                    if (j == 0)
                        year = Convert.ToInt32(i);
                    else if (j == 1)
                        manth = Convert.ToInt32(i);
                    else
                        day = Convert.ToInt32(i);
                    j++;
                }
                century = year % 100;
                lunar_excute(day, manth, year, century);
            }

        }
        private void milladi_excute(int day,int manth,int year,int century)
        {
            if (manth == 10 && day <= 10)
            {
                day_leap_do_m_action(year, century, manth, day);
            }
            else if (manth < 10)
            {
                day_leap_do_m_action(year, century, manth, day);
            }
            else
            {
                year += 622;
                century = year % 100;
                 manth -= 1;
                day -= 10;
                if (manth == 10)
                {
                    day = day + 20;
                }
                else if (manth == 11)
                {
                    day = day + 50;
                }

                manth = 1;


                if (year % 4 == 0 && century == 0)
                {
                    if (year % 400 == 0)
                    {
                        leap_m_year(year, manth, day);
                    }
                    else
                    {
                        normal_year(day, manth, year);
                    }
                }
                else if (year % 4 == 0)
                {
                    leap_m_year(year, manth, day);
                }
                else
                    normal_year(day, manth, year);
            }
        }
        private void shms_excute(int day,int manth,int year,int century)
        {
            if (manth < 4)
            {
                day_leap_do_sh_action(year, century, manth, day);
            }
            else
            {
                year -= 621;

                for (int i = 0; i < plusmday.Length && (i + 2) <= manth; i++)
                {
                    day = day + plusmday[i];
                }

                manth = 1;

                if (year % 4 == 0 && century == 0)
                {
                    if (year % 400 == 0)
                    {
                        day -= 80;
                        leap_sh_year(year, century, manth, day);
                    }
                    else
                    {
                        day -= 79;
                        normal_sh_year(year, manth, day);
                    }
                }
                else if (year % 4 == 0)
                {
                    day -= 80;
                    leap_sh_year(year, century, manth, day);
                }
                else
                {
                    day -= 79;
                    normal_sh_year(day, manth, year);
                }
            }
        }
        private void lunar_excute(int day,int manth,int year,int century)
        {
            int completeYear = year / 30;
            int leftYear = year % 30;
            int _206day;
            int day2 = 0;
            int year_count = 1;

            if (leftYear != 0)
            {
                day = sh_day(day, manth, year, century);
                leftYear--;
                year--;
                day += leftY_sh_day(day2, year, leftYear, century);
                _206day = completeYear * 206;
            }
            else
            {
                --completeYear;
                _206day = completeYear * 206;
                leftYear = 30;

                day = sh_day(day, manth, year, century);
                leftYear--; year--;
                day += leftY_sh_day(day2, year, leftYear, century);
            }
            day += _206day;
            year = 0;

            if (completeYear != 0)
            {
                day -= 119;
                manth = 1;
                while (day > 354)
                {
                    if (check(year_count))
                    {
                        year_count++;
                        day -= 355;
                    }
                    else
                    {
                        year_count++;
                        day -= 354;
                    }
                }
                year = year_count + (completeYear * 30);

                divide_day_lun(day, manth, year, check(year));
            }
            else
            {
                day -= 119;
                manth = 1;
                while (day > 354)
                {
                    if (check(year_count))
                    {
                        year_count++;
                        day -= 355;
                    }
                    else
                    {
                        year_count++;
                        day -= 354;
                    }
                }
                year = year_count;

                divide_day_lun(day, manth, year, check(year));
            }
        }
        private void lblChange_Click(object sender, EventArgs e)
        {

        }
        private void leap_m_year(int year,int manth ,int day )
        {
                for (int i = 0; i < plusmday.Length; i++)
                {
                    if (day > plusmday[i])
                    {
                        day = day - plusmday[i];
                        manth++;
                    }
                    else
                    {
                        lblAD.Text = (Convert.ToString(year)) +"/"+ (Convert.ToString(manth))+ "/"+ (Convert.ToString(day));
                        break;
                    }
                }
        }
        private void day_leap_do_m_action(int year,int century,int manth, int day)
        {
            manth -= 1;
            year += 621;
            if (manth <= 6)
            {
                day = day + (manth * 31);

            }
            else
            {
                day = day + (6 * 31) + ((manth - 6) * 30);
            }

            manth = 1;

            if (year % 4 == 0 && century == 0)
            {
                if (year %400 == 0)
                {
                    day += 80;
                    leap_m_year(year, manth, day);
                }
                else
                {
                    day += 79;
                    leap_m_year(year, manth, day);
                }
            }
            else if(year % 4 == 0)
            {
                day += 80;
                leap_m_year(year, manth, day);
            }
            else
            {
                day += 79;
                normal_year(day, manth, year);
            }
        }
        private void normal_year(int day, int manth,int year)
        {
            for (int i = 0; i < mday.Length; i++)
            {
                if (day > mday[i])
                {
                    day = day - mday[i];
                    manth++;
                }
                else
                {
                    lblAD.Text = (Convert.ToString(year))+"/" + (Convert.ToString(manth))+"/" + (Convert.ToString(day));
                    break;
                }
            }
        }
        private void leap_sh_year(int year,int century, int manth, int day)
        {
            
            if (year / 400 == 0)
            {
                for (int i = 0; i < plusshday.Length; i++)
                {
                    if (day > plusshday[i])
                    {
                        day = day - plusshday[i];
                        manth++;
                    }
                    else
                    {
                        lblSH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                        break;
                    }
                }
            }
            else
            {
                for (int i = 0; i < shday.Length; i++)
                {
                    if (day > shday[i])
                    {
                        day = day - shday[i];
                        manth++;
                    }
                    else
                    {
                        lblSH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                        break;
                    }
                }
            }
        }
        private int find_one_day_to_sh_problem(int manth,int day)
        {
            if (manth >=2)
            {
                if (manth == 2 && day == 29)
                {
                    return (day + 31);
                }
                else if(manth == 2)
                {
                    return (day + 31);
                }else
                    return (day + 60);
            }
            else
            {
                return (day);
            }
        }
        private void day_leap_do_sh_action(int year, int century, int manth, int day)
        {
            day = find_one_day_to_sh_problem(manth, day);

            year -= 622;
            century = year % 100;
            
            manth = 1;

            if (year % 4 == 0 && century == 0)
            {
                if (year % 400 == 0)
                {
                    day += 286;
                    leap_sh_year(year, century, manth, day);
                }else
                {
                    day += 286;
                    normal_year(day, manth, year);
                }
            }
            else if(year % 4 == 0)
            {
                day += 286;
                leap_sh_year(year, century, manth, day);

            }
            else
            {
                day += 286;
                normal_sh_year(day, manth, year);
            }
        }
        private void normal_sh_year(int day,int manth, int year)
        {
            
            for (int i = 0; i < shday.Length; i++)
            {
                if (day > shday[i])
                {
                    day = day - shday[i];
                    manth++;
                }
                else
                {
                    lblSH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                    break;
                }
            }
        }
        private int sh_day(int day,int manth,int year,int century)
        {
            if (year % 4 == 0 && century == 0)
            {
                if (year % 400 == 0)
                {
                    for (int i = 0; i < manth-1; i++)
                    {
                        day += plusshday[i];
                    }
                    return day;
                }
                else
                {
                    for (int i = 0; i < manth-1; i++)
                    {
                        day += shday[i];
                    }
                    return day;
                }
            }
            else if (year % 4 == 0)
            {
                for (int i = 0; i < manth - 1; i++)
                {
                    day += plusshday[i];
                }
                return day;

            }
            else
            {
                for (int i = 0; i < manth - 1; i++)
                {
                    day += shday[i];
                }
                return day;

            }
        }
        private int leftY_sh_day(int day2,int year2, int leftYear, int century)
        {
            while (leftYear >= 1 )
            {
                if (year2 % 4 == 0 && century == 0)
                {
                    if (year2 % 400 == 0)
                    {
                        day2 += 366;
                        year2--;
                        leftYear--;
                    }
                    else
                    {
                        day2 += 365;
                        year2--;
                        leftYear--;
                    }
                }
                else if (year2 % 4 == 0)
                {
                    day2 += 366;
                    year2--;
                    leftYear--;
                }
                else
                {
                    day2 += 365;
                    year2--;
                    leftYear--;
                }
            }
            return day2;
        }
        private bool check(int year_count)
        {
            
            for (int i = 0; i < taghsem.Length; i++)
            {
            if (year_count % 30 == taghsem[i])
                {
                    return true;
                }
            }
            return false;
        }
        private void divide_day_lun(int day,int manth,int year,Boolean check)
        {
            if (check)
            {
                for (int j = 0; j <= 11; j++)
                {
                    if (day > pluslunarday[j])
                    {
                        day -= pluslunarday[j];
                        manth++;
                    }
                    else
                    {
                        lblAH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                        break;
                    }

                }
            }
            else
            {
                for (int j = 0; j <= 11; j++)
                {
                    if (day > lunarday[j])
                    {
                        day -= lunarday[j];
                        manth++;
                    }
                    else
                    {
                        lblAH.Text = (Convert.ToString(year)) + "/" + (Convert.ToString(manth)) + "/" + (Convert.ToString(day));
                        break;
                    }

                }
            }
        }
 

        private void rdbLunar_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdbMilladi_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
